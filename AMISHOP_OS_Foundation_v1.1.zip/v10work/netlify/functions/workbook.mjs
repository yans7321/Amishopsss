// Full YANS workbook migration bridge.
// Relational endpoints remain authoritative for normalized modules; this
// versioned JSONB snapshot preserves every legacy operational field during
// the staged migration so no existing module data is silently discarded.
import { isDbConfigured, runMigrations, q, resolveSession, withTransaction } from "./_db.mjs";
import { json, errorResponse, readJson, safeDbError } from "./_http.mjs";

const KIND = "full_backup_v1";
const MAX_BYTES = 4 * 1024 * 1024;

function validPayload(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  if (value.version !== 1 || !value.data || typeof value.data !== "object" || Array.isArray(value.data)) return false;
  // Credentials and login state must never be stored in the business workbook.
  if ("users" in value.data || "currentUser" in value.data || "password" in value.data) return false;
  return true;
}

export default async function handler(req) {
  if (!isDbConfigured()) return json({ error: "db_not_configured", message: "Database belum dikonfigurasi." }, 503);
  try { await runMigrations(); } catch (e) { return safeDbError(e); }
  const user = await resolveSession(req);
  if (!user) return errorResponse(401, "unauthorized", "Sesi tidak valid. Silakan login ulang.");
  try {
    if (req.method === "GET") {
      const rows = await q(
        `SELECT payload, revision, updated_at FROM yans_workbook_state WHERE user_id = $1 AND kind = $2 LIMIT 1`,
        [user.id, KIND]
      );
      const row = rows[0];
      return json({ exists: !!row, revision: row ? Number(row.revision) : 0, payload: row ? row.payload : null, updatedAt: row ? row.updated_at : null });
    }
    if (req.method === "PUT") {
      const raw = await req.text();
      if (new TextEncoder().encode(raw).byteLength > MAX_BYTES) return errorResponse(413, "payload_too_large", "Ukuran data melebihi batas 4 MB.");
      let body;
      try { body = JSON.parse(raw); } catch { return errorResponse(400, "invalid_json", "Format data tidak valid."); }
      if (!validPayload(body.payload)) return errorResponse(400, "invalid_payload", "Snapshot tidak valid atau memuat data akun.");
      const baseRevision = Number.isInteger(body.baseRevision) && body.baseRevision >= 0 ? body.baseRevision : null;
      if (baseRevision === null) return errorResponse(400, "revision_required", "Nomor revisi wajib disertakan.");
      const result = await withTransaction(async (tx) => {
        const current = await tx.query(
          `SELECT revision FROM yans_workbook_state WHERE user_id = $1 AND kind = $2 FOR UPDATE`,
          [user.id, KIND]
        );
        const revision = current[0] ? Number(current[0].revision) : 0;
        if (revision !== baseRevision) return { conflict: true, revision };
        const next = revision + 1;
        await tx.query(
          `INSERT INTO yans_workbook_state (user_id, kind, payload, revision, updated_at)
           VALUES ($1, $2, $3::jsonb, $4, now())
           ON CONFLICT (user_id, kind) DO UPDATE SET payload = EXCLUDED.payload, revision = EXCLUDED.revision, updated_at = now()`,
          [user.id, KIND, JSON.stringify(body.payload), next]
        );
        return { conflict: false, revision: next };
      });
      if (result.conflict) return json({ error: "revision_conflict", message: "Ada perubahan data dari sesi lain. Muat ulang data server sebelum menyimpan lagi.", revision: result.revision }, 409);
      return json({ ok: true, revision: result.revision });
    }
    return errorResponse(405, "method_not_allowed", "Gunakan GET atau PUT.");
  } catch (e) { return safeDbError(e); }
}
