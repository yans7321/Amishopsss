// AMISHOP / AMIYA purchase documents — authenticated CRUD + stock/supplier posting.
import crypto from 'node:crypto';
import { isDbConfigured, runMigrations, q, resolveSession, withTransaction } from './_db.mjs';
import { json, readJson, safeDbError } from './_http.mjs';
const UNITS = new Set(['amishop','amiya']);
const str = (v,n=180) => typeof v === 'string' ? v.trim().slice(0,n) : '';
const num = v => { const n=Number(v); return Number.isFinite(n)&&n>=0&&n<=1e12?n:null; };
const key = s => String(s||'').trim().toLocaleLowerCase('id-ID');
function skuFor(item){
  const supplied=str(item.sku,80).toUpperCase();
  if(supplied) return supplied;
  const seed=`${key(item.name)}|${key(item.unit||'pcs')}`;
  return `AUTO-${crypto.createHash('sha256').update(seed).digest('hex').slice(0,12).toUpperCase()}`;
}
function normalize(b){
 const unit=str(b.unit,20).toLowerCase(), supplier=str(b.supplier,180), date=str(b.date,10);
 if(!UNITS.has(unit)) return {error:'Unit pembelian harus AMISHOP atau AMIYA.'};
 if(!supplier) return {error:'Nama pemasok wajib diisi.'};
 if(!/^\d{4}-\d{2}-\d{2}$/.test(date) || isNaN(Date.parse(date+'T00:00:00Z'))) return {error:'Tanggal pembelian tidak valid.'};
 if(!Array.isArray(b.items)||!b.items.length||b.items.length>100) return {error:'Minimal satu dan maksimal 100 item pembelian.'};
 const items=[]; let subtotal=0;
 for(const x of b.items){const name=str(x.name,180),qty=num(x.qty),price=num(x.price),itemUnit=str(x.unit,30)||'pcs';if(!name||qty===null||qty<=0||price===null)return {error:'Nama barang, jumlah positif, dan harga valid wajib diisi.'};const total=Math.round(qty*price*100)/100;subtotal+=total;items.push({name,sku:skuFor({...x,name,unit:itemUnit}),unit:itemUnit,qty,price,total});}
 const tax=num(b.tax??0); if(tax===null)return {error:'Pajak tidak valid.'};
 return {value:{unit,supplier,date,invoiceNo:str(b.invoiceNo,80),notes:str(b.notes,1000),items,subtotal:Math.round(subtotal*100)/100,tax,total:Math.round((subtotal+tax)*100)/100}};
}
async function postPurchase(user,v){
 return withTransaction(async tx=>{
  const supplierKey=key(v.supplier);
  await tx.query(`INSERT INTO business_suppliers(user_id,unit,name,name_key) VALUES($1,$2,$3,$4)
    ON CONFLICT(user_id,unit,name_key) DO UPDATE SET name=EXCLUDED.name,updated_at=now()`,[user.id,v.unit,v.supplier,supplierKey]);
  const rows=await tx.query(`INSERT INTO purchase_documents(user_id,unit,supplier,purchase_date,invoice_no,notes,items,subtotal,tax,total)
    VALUES($1,$2,$3,$4,$5,$6,$7::jsonb,$8,$9,$10)
    RETURNING id,unit,supplier,purchase_date,invoice_no,notes,items,subtotal,tax,total,created_at`,
    [user.id,v.unit,v.supplier,v.date,v.invoiceNo,v.notes,JSON.stringify(v.items),v.subtotal,v.tax,v.total]);
  const purchase=rows[0];
  for(const item of v.items){
   const existing=await tx.query(`SELECT id,stock_qty,average_cost FROM business_inventory WHERE user_id=$1 AND unit=$2 AND sku=$3 FOR UPDATE`,[user.id,v.unit,item.sku]);
   let inv;
   if(existing.length){
    const oldQty=Number(existing[0].stock_qty),oldCost=Number(existing[0].average_cost),newQty=oldQty+item.qty;
    const avg=newQty>0?((oldQty*oldCost)+(item.qty*item.price))/newQty:item.price;
    const updated=await tx.query(`UPDATE business_inventory SET name=$4,item_unit=$5,stock_qty=$6,average_cost=$7,updated_at=now() WHERE id=$1 AND user_id=$2 AND unit=$3 RETURNING id`,[existing[0].id,user.id,v.unit,item.name,item.unit,newQty,avg]); inv=updated[0];
   }else{
    const created=await tx.query(`INSERT INTO business_inventory(user_id,unit,sku,name,item_unit,stock_qty,average_cost) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,[user.id,v.unit,item.sku,item.name,item.unit,item.qty,item.price]); inv=created[0];
   }
   await tx.query(`INSERT INTO inventory_movements(user_id,unit,inventory_id,movement_type,quantity,unit_cost,source_type,source_id,notes)
    VALUES($1,$2,$3,'purchase_in',$4,$5,'purchase',$6,$7)`,[user.id,v.unit,inv.id,item.qty,item.price,purchase.id,`Pembelian ${v.invoiceNo||('#'+purchase.id)} dari ${v.supplier}`]);
  }
  return purchase;
 });
}
export default async function handler(req){
 try{
  if(!isDbConfigured()) return json({error:'DB_NOT_CONFIGURED',message:'Database belum dikonfigurasi.'},503);
  await runMigrations(); const user=await resolveSession(req); if(!user)return json({error:'UNAUTHORIZED',message:'Silakan login.'},401);
  if(req.method==='GET'){
   const unit=new URL(req.url).searchParams.get('unit');
   const rows=await q(`SELECT id,unit,supplier,purchase_date,invoice_no,notes,items,subtotal,tax,total,created_at FROM purchase_documents WHERE user_id=$1 AND ($2::text IS NULL OR unit=$2) ORDER BY purchase_date DESC,id DESC LIMIT 300`,[user.id,UNITS.has(unit)?unit:null]);
   return json({items:rows.map(r=>({...r,date:r.purchase_date, purchase_date:undefined, subtotal:Number(r.subtotal),tax:Number(r.tax),total:Number(r.total)}))});
  }
  if(req.method==='POST'){
   const b=await readJson(req);const n=normalize(b);if(n.error)return json({error:'VALIDATION',message:n.error},400);const row=await postPurchase(user,n.value);
   return json({item:{...row,date:row.purchase_date,subtotal:Number(row.subtotal),tax:Number(row.tax),total:Number(row.total)}},201);
  }
  if(req.method==='DELETE'){
   const id=Number(new URL(req.url).searchParams.get('id'));if(!Number.isInteger(id)||id<=0)return json({error:'VALIDATION',message:'ID tidak valid.'},400);
   const outcome=await withTransaction(async tx=>{
    const docs=await tx.query('SELECT id,unit FROM purchase_documents WHERE id=$1 AND user_id=$2 FOR UPDATE',[id,user.id]);
    if(!docs.length)return {missing:true};
    const moves=await tx.query(`SELECT inventory_id,SUM(quantity) AS qty FROM inventory_movements WHERE user_id=$1 AND source_type='purchase' AND source_id=$2 GROUP BY inventory_id`,[user.id,id]);
    for(const m of moves){
     const current=await tx.query('SELECT stock_qty FROM business_inventory WHERE id=$1 AND user_id=$2 FOR UPDATE',[m.inventory_id,user.id]);
     if(!current.length || Number(current[0].stock_qty)+1e-9<Number(m.qty))return {conflict:true};
    }
    for(const m of moves) await tx.query('UPDATE business_inventory SET stock_qty=stock_qty-$3,updated_at=now() WHERE id=$1 AND user_id=$2',[m.inventory_id,user.id,m.qty]);
    await tx.query("DELETE FROM inventory_movements WHERE user_id=$1 AND source_type='purchase' AND source_id=$2",[user.id,id]);
    await tx.query('DELETE FROM purchase_documents WHERE id=$1 AND user_id=$2',[id,user.id]);
    return {ok:true};
   });
   if(outcome.missing)return json({error:'NOT_FOUND',message:'Nota tidak ditemukan.'},404);
   if(outcome.conflict)return json({error:'STOCK_ALREADY_USED',message:'Nota tidak dapat dihapus karena sebagian stok pembelian sudah terpakai. Buat retur/penyesuaian stok, jangan hapus transaksi asal.'},409);
   return json({ok:true});
  }
  return json({error:'METHOD_NOT_ALLOWED'},405);
 }catch(e){return safeDbError(e);}
}
