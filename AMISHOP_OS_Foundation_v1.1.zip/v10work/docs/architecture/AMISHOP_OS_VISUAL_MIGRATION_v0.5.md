# AMISHOP Business OS — Visual Migration v0.5

## Prinsip utama
- Seluruh halaman, formulir, field, tombol, alur kerja, dan aturan bisnis Konveksi YANS dipertahankan.
- Perubahan v0.5 berfokus pada tampilan dan integrasi navigasi portal.
- Tidak ada modul atau field operasional yang sengaja dihapus.

## Perubahan v0.5
- Menambahkan `konveksi-yans/` sebagai lokasi modul YANS di dalam portal AMISHOP.
- Memperbaiki jalur relatif asset agar halaman bersarang dapat memuat stylesheet, JavaScript, dan logo dari direktori induk.
- Menambahkan stylesheet presentasi `yans-premium.css` untuk tema charcoal, warm ivory, dan muted gold yang selaras dengan logo YANS.
- Menambahkan tautan kembali ke AMISHOP OS pada topbar YANS.
- Semua perubahan visual bersifat CSS/presentasi; file JavaScript operasional dan isi HTML sumber dipertahankan.

## Batasan yang belum selesai
- Integrasi database PostgreSQL sebagai sumber data utama belum selesai.
- Autentikasi dan migrasi akun harus diuji end-to-end pada deployment HTTPS dan database yang dikonfigurasi.
- Modul lain seperti AMIYA DAILY dan AMISHOP masih berupa fondasi/placeholder, bukan aplikasi operasional.
- Sebelum produksi, lakukan uji regresi seluruh alur input, edit, hapus, cetak, backup, restore, hak akses, dan laporan.
