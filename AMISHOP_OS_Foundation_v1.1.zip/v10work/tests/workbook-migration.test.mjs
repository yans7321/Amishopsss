import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const api = fs.readFileSync(new URL('../app-api.js', import.meta.url), 'utf8');
const endpoint = fs.readFileSync(new URL('../netlify/functions/workbook.mjs', import.meta.url), 'utf8');
const db = fs.readFileSync(new URL('../netlify/functions/_db.mjs', import.meta.url), 'utf8');
const toml = fs.readFileSync(new URL('../netlify.toml', import.meta.url), 'utf8');

test('workbook snapshot excludes account credentials and browser auth state', () => {
  assert.match(api, /key === "users" \|\| key === "currentUser"/);
  assert.match(api, /password\|password_hash\|token\|access_token\|refresh_token\|session/i);
  assert.match(endpoint, /"users" in value\.data \|\| "currentUser" in value\.data/);
});

test('workbook endpoint is session-authenticated and revision guarded', () => {
  assert.match(endpoint, /resolveSession\(req\)/);
  assert.match(endpoint, /FOR UPDATE/);
  assert.match(endpoint, /revision_conflict/);
  assert.match(endpoint, /MAX_BYTES = 4 \* 1024 \* 1024/);
});

test('workbook schema migration and API route exist', () => {
  assert.match(db, /0008_workbook_revision/);
  assert.match(db, /ALTER TABLE yans_workbook_state ADD COLUMN IF NOT EXISTS revision/);
  assert.match(toml, /from = "\/api\/workbook"[\s\S]*?to = "\/\.netlify\/functions\/workbook"/);
});

test('client restores server workbook and migrates local workbook on first login', () => {
  assert.match(api, /function restoreWorkbook\(\)/);
  assert.match(api, /if \(res\.exists && res\.payload\)/);
  assert.match(api, /migrated: saved\.ok/);
  assert.match(api, /hook\("saveData"/);
});
