# AMISHOP Business OS — v1.1

- Preserves the existing Konveksi YANS application and its workflows.
- Extends purchase documents for AMISHOP and AMIYA DAILY with transactional supplier and stock posting.
- Adds item master, supplier master, stock movement history, and controlled stock adjustments.
- Uses weighted-average inventory cost for purchase inflows.
- Blocks stock-out below zero and blocks deletion of purchase notes whose stock has already been consumed.
- Adds a fresh-database migration ordering fix and migration `0010_inventory_suppliers`.
- Does not yet implement accounts payable, payment status, supplier settlement, or journal/P&L posting.
