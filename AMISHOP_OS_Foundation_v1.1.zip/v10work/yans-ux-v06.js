/* YANS UX v0.6: command palette + reliable mobile navigation. Does not replace legacy business logic. */
(() => {
  const nav = [
    ['dashboard','Dashboard','fa-chart-pie'],['tab1','Pekerjaan','fa-briefcase'],['tab2','Ambil Jahit','fa-scissors'],
    ['tab3','Storan','fa-box-archive'],['tab5','Kiriman Barang','fa-truck-fast'],['tab4','Gajian','fa-users-rectangle'],
    ['kasbon','Cash Advance / Kasbon','fa-hand-holding-dollar'],['tab6','Laporan Pengeluaran','fa-receipt'],
    ['tab7','Profit & Loss','fa-chart-line'],['aset','Aset Perusahaan','fa-boxes-stacked'],
    ['arsip','Arsip & Pekerja','fa-folder-tree'],['member','Member & Akses','fa-user-shield']
  ];
  const $ = (s,root=document) => root.querySelector(s);
  function mount(){
    if(!$('#yx-mobile-scrim')){
      const scrim=document.createElement('div');scrim.id='yx-mobile-scrim';scrim.addEventListener('click',closeMobile);document.body.appendChild(scrim);
    }
    if(!$('#yx-command')){
      const overlay=document.createElement('div');overlay.id='yx-command';overlay.setAttribute('aria-hidden','true');
      overlay.innerHTML='<div id="yx-command-panel" role="dialog" aria-modal="true" aria-label="Pencarian menu"><input id="yx-command-input" type="search" placeholder="Cari menu Konveksi YANS…" autocomplete="off"><div id="yx-command-results"></div><div class="yx-command-hint">Enter untuk membuka · Esc untuk menutup · Ctrl K untuk mencari</div></div>';
      overlay.addEventListener('click',e=>{if(e.target===overlay)closeCommand()});document.body.appendChild(overlay);
      $('#yx-command-input',overlay).addEventListener('input',renderResults);
      $('#yx-command-input',overlay).addEventListener('keydown',e=>{if(e.key==='Enter'){const first=$('.yx-command-item',overlay);if(first)first.click()}if(e.key==='Escape')closeCommand()});
    }
    const search=$('.glass-header .fa-magnifying-glass');
    if(search){const wrapper=search.closest('div');if(wrapper){wrapper.setAttribute('role','button');wrapper.setAttribute('tabindex','0');wrapper.setAttribute('aria-label','Cari menu');wrapper.style.cursor='pointer';wrapper.addEventListener('click',openCommand);wrapper.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openCommand()}})}}
  }
  function renderResults(){
    const q=($('#yx-command-input')?.value||'').trim().toLocaleLowerCase('id');
    const results=nav.filter(x=>(x[1]+' '+x[0]).toLocaleLowerCase('id').includes(q));
    const target=$('#yx-command-results');if(!target)return;
    target.innerHTML=results.length?results.map(x=>`<button type="button" class="yx-command-item" data-tab="${x[0]}"><i class="fa-solid ${x[2]}"></i><span>${x[1]}</span></button>`).join(''):'<div style="padding:20px;text-align:center;color:#8b8375;font-size:12px">Menu tidak ditemukan.</div>';
    target.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>{if(typeof window.switchTab==='function')window.switchTab(b.dataset.tab);closeCommand()}));
  }
  function openCommand(){const el=$('#yx-command');if(!el)return;el.classList.add('open');el.setAttribute('aria-hidden','false');$('#yx-command-input').value='';renderResults();setTimeout(()=>$('#yx-command-input').focus(),20)}
  function closeCommand(){const el=$('#yx-command');if(!el)return;el.classList.remove('open');el.setAttribute('aria-hidden','true')}
  function closeMobile(){const sb=$('#sidebar'),scrim=$('#yx-mobile-scrim');if(sb)sb.classList.remove('yx-open');if(scrim)scrim.classList.remove('yx-visible')}
  function openMobile(){const sb=$('#sidebar'),scrim=$('#yx-mobile-scrim');if(sb)sb.classList.add('yx-open');if(scrim)scrim.classList.add('yx-visible')}
  const oldToggle=window.toggleMobileSidebar;
  window.toggleMobileSidebar=function(){const sb=$('#sidebar');if(!sb)return;if(window.innerWidth>=768){if(typeof oldToggle==='function')oldToggle();return}if(sb.classList.contains('yx-open'))closeMobile();else openMobile()};
  const oldSwitch=window.switchTab;
  window.switchTab=function(id){if(typeof oldSwitch==='function')oldSwitch(id);closeMobile()};
  document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openCommand()}if(e.key==='Escape'){closeCommand();closeMobile()}});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
})();
