import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(new URL('..',import.meta.url).pathname);
const db=fs.readFileSync(path.join(root,'netlify/functions/_db.mjs'),'utf8');
const purchases=fs.readFileSync(path.join(root,'netlify/functions/purchases.mjs'),'utf8');
const inventory=fs.readFileSync(path.join(root,'netlify/functions/inventory.mjs'),'utf8');
const toml=fs.readFileSync(path.join(root,'netlify.toml'),'utf8');
test('fresh database: foundation migration precedes purchase foreign key migration',()=>{
 assert.ok(db.indexOf('name: "0001_foundation_tables"')<db.indexOf('name: "0009_purchase_documents"'));
});
test('inventory schema is unit-scoped and records stock movement history',()=>{
 for(const token of ['business_suppliers','business_inventory','inventory_movements',"CHECK (unit IN ('amishop','amiya'))",'UNIQUE(user_id,unit,sku)']) assert.ok(db.includes(token),token);
});
test('purchase save posts supplier, stock quantity, weighted cost and movement atomically',()=>{
 for(const token of ['withTransaction','business_suppliers','business_inventory','average_cost','purchase_in','inventory_movements']) assert.ok(purchases.includes(token),token);
});
test('manual stock adjustment validates direction and prevents negative stock',()=>{
 for(const token of ["action==='adjustment'",'INSUFFICIENT_STOCK','adjustment_in','adjustment_out','FOR UPDATE']) assert.ok(inventory.includes(token),token);
});
test('inventory API route is configured',()=>assert.ok(toml.includes('from = "/api/inventory"')));
