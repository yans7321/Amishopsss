# AMISHOP Business OS — YANS Data Migration v0.7

## Scope

This release adds a staged, loss-preserving persistence bridge for the complete legacy YANS workbook. It does not yet claim that every legacy field has been normalized into dedicated relational tables.

## What changed

- Added authenticated `GET /api/workbook` and `PUT /api/workbook` endpoint.
- Added migration `0008_workbook_revision` to version the existing `yans_workbook_state` records.
- The client serializes all enumerable business properties on the legacy `db` object, excluding `users` and `currentUser` and recursively excluding credential/session-like keys.
- On first login for a server account, the browser's existing operational workbook is uploaded once to PostgreSQL JSONB.
- On later logins, the server workbook is restored into the existing YANS app and cached locally.
- Every legacy `saveData()` call schedules a debounced server save.
- Revision checks reject stale writes (HTTP 409) instead of silently overwriting newer data from another browser/session.
- Payload limit is 4 MiB.

## Preserved workbook fields

The bridge includes all business properties currently present on the original `db` object, including `perusahaan`, `pekerja`, `tab1`, `tab2`, `tab3`, `tab5`, `gajiStatus`, `expenses`, `kasbon`, and `aset`. Any additional enumerable business property added later is included automatically unless it is an account/session credential field.

## Important boundaries

- Dedicated relational endpoints already exist for jobs, tailoring pickups, storages, shipments, expenses, cash advances, and assets. The snapshot bridge is the safety net while all legacy modules are progressively switched to normalized server records.
- This is a staged migration, not proof that every table is already the only source of truth.
- PostgreSQL connectivity and live multi-user behavior have not been tested in this environment because the `pg` dependency is not installed and no database credentials are configured here.
- Before production, install dependencies (`npm ci`), configure `DATABASE_URL`, run `npm run db:migrate`, then test login, first-time import, second-device restore, edits, and conflict handling on a staging deployment.
- Keep an external JSON backup before the first production migration.
