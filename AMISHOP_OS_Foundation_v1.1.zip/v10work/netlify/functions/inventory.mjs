// Unit-scoped inventory and supplier master data for AMISHOP / AMIYA DAILY.
import { isDbConfigured, runMigrations, q, resolveSession, withTransaction } from './_db.mjs';
import { json, readJson, safeDbError } from './_http.mjs';
const UNITS=new Set(['amishop','amiya']);
const s=(v,n=180)=>typeof v==='string'?v.trim().slice(0,n):'';
const n=v=>{const x=Number(v);return Number.isFinite(x)&&x>=0&&x<=1e12?x:null;};
const key=v=>s(v,180).toLocaleLowerCase('id-ID');
export default async function handler(req){
 try{
  if(!isDbConfigured())return json({error:'DB_NOT_CONFIGURED',message:'Database belum dikonfigurasi.'},503);
  await runMigrations();const user=await resolveSession(req);if(!user)return json({error:'UNAUTHORIZED',message:'Silakan login.'},401);
  if(req.method==='GET'){
   const u=new URL(req.url),unit=u.searchParams.get('unit');if(!UNITS.has(unit))return json({error:'VALIDATION',message:'Unit harus amishop atau amiya.'},400);
   const [items,suppliers,movements]=await Promise.all([
    q(`SELECT id,sku,name,item_unit,stock_qty,average_cost,min_stock,updated_at FROM business_inventory WHERE user_id=$1 AND unit=$2 ORDER BY name`,[user.id,unit]),
    q(`SELECT id,name,contact,phone,notes,updated_at FROM business_suppliers WHERE user_id=$1 AND unit=$2 ORDER BY name`,[user.id,unit]),
    q(`SELECT m.id,m.movement_type,m.quantity,m.unit_cost,m.source_type,m.source_id,m.notes,m.created_at,i.sku,i.name FROM inventory_movements m JOIN business_inventory i ON i.id=m.inventory_id WHERE m.user_id=$1 AND m.unit=$2 ORDER BY m.created_at DESC,m.id DESC LIMIT 100`,[user.id,unit])
   ]);
   return json({items:items.map(x=>({...x,stock_qty:Number(x.stock_qty),average_cost:Number(x.average_cost),min_stock:Number(x.min_stock)})),suppliers,movements:movements.map(x=>({...x,quantity:Number(x.quantity),unit_cost:Number(x.unit_cost)}))});
  }
  if(req.method==='POST'){
   const b=await readJson(req),unit=s(b.unit,20).toLowerCase(),action=s(b.action,30);if(!UNITS.has(unit))return json({error:'VALIDATION',message:'Unit harus amishop atau amiya.'},400);
   if(action==='supplier'){
    const name=s(b.name);if(!name)return json({error:'VALIDATION',message:'Nama pemasok wajib diisi.'},400);
    const rows=await q(`INSERT INTO business_suppliers(user_id,unit,name,name_key,contact,phone,notes) VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT(user_id,unit,name_key) DO UPDATE SET name=EXCLUDED.name,contact=EXCLUDED.contact,phone=EXCLUDED.phone,notes=EXCLUDED.notes,updated_at=now() RETURNING id,name,contact,phone,notes`,[user.id,unit,name,key(name),s(b.contact,120),s(b.phone,60),s(b.notes,500)]);
    return json({item:rows[0]},201);
   }
   if(action==='item'){
    const sku=s(b.sku,80).toUpperCase(),name=s(b.name),itemUnit=s(b.item_unit,30)||'pcs',min=n(b.min_stock??0);if(!sku||!name||min===null)return json({error:'VALIDATION',message:'SKU, nama barang, dan stok minimum valid wajib diisi.'},400);
    const rows=await q(`INSERT INTO business_inventory(user_id,unit,sku,name,item_unit,min_stock) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(user_id,unit,sku) DO UPDATE SET name=EXCLUDED.name,item_unit=EXCLUDED.item_unit,min_stock=EXCLUDED.min_stock,updated_at=now() RETURNING id,sku,name,item_unit,stock_qty,average_cost,min_stock`,[user.id,unit,sku,name,itemUnit,min]);
    return json({item:{...rows[0],stock_qty:Number(rows[0].stock_qty),average_cost:Number(rows[0].average_cost),min_stock:Number(rows[0].min_stock)}},201);
   }
   if(action==='adjustment'){
    const id=Number(b.inventory_id),qty=n(b.quantity),cost=n(b.unit_cost??0),direction=s(b.direction,10),reason=s(b.reason,500);if(!Number.isInteger(id)||id<=0||qty===null||qty<=0||cost===null||!['in','out'].includes(direction)||!reason)return json({error:'VALIDATION',message:'Barang, jumlah, arah, dan alasan penyesuaian wajib valid.'},400);
    const result=await withTransaction(async tx=>{
     const rows=await tx.query('SELECT id,stock_qty,average_cost FROM business_inventory WHERE id=$1 AND user_id=$2 AND unit=$3 FOR UPDATE',[id,user.id,unit]);if(!rows.length)return {missing:true};
     const old=Number(rows[0].stock_qty),next=direction==='in'?old+qty:old-qty;if(next<0)return {negative:true};
     const oldCost=Number(rows[0].average_cost),avg=direction==='in'&&next>0?((old*oldCost)+(qty*cost))/next:oldCost;
     await tx.query('UPDATE business_inventory SET stock_qty=$4,average_cost=$5,updated_at=now() WHERE id=$1 AND user_id=$2 AND unit=$3',[id,user.id,unit,next,avg]);
     await tx.query(`INSERT INTO inventory_movements(user_id,unit,inventory_id,movement_type,quantity,unit_cost,source_type,notes) VALUES($1,$2,$3,$4,$5,$6,'adjustment',$7)`,[user.id,unit,id,direction==='in'?'adjustment_in':'adjustment_out',qty,cost,reason]);return {ok:true,stock_qty:next};
    });
    if(result.missing)return json({error:'NOT_FOUND',message:'Barang tidak ditemukan.'},404);if(result.negative)return json({error:'INSUFFICIENT_STOCK',message:'Stok tidak boleh menjadi negatif.'},409);return json(result);
   }
   return json({error:'VALIDATION',message:'Aksi tidak dikenal.'},400);
  }
  return json({error:'METHOD_NOT_ALLOWED'},405);
 }catch(e){return safeDbError(e);}
}
