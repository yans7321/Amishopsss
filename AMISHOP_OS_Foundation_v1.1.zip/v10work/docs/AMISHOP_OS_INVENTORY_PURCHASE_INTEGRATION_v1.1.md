# AMISHOP Business OS — Inventory & Supplier Integration v1.1

## Scope
Additive extension of Foundation v1.0. Existing Konveksi YANS screens, data flows, documents and business logic are retained. Purchase and inventory data are separated by authenticated user and business unit (`amishop` / `amiya`).

## Included
- New `/persediaan/` page for AMISHOP and AMIYA DAILY.
- Unit-scoped item master: SKU, item name, unit, current stock, minimum stock and average cost.
- Unit-scoped supplier master with contact, phone and notes.
- Stock movement history and manual stock-in / stock-out adjustments with mandatory reason. Negative stock is rejected.
- Saving a purchase document now runs in a database transaction: upserts supplier, saves the purchase note, increases stock, updates weighted-average cost and records `purchase_in` movements.
- A supplied SKU is used as the inventory key. If omitted, a stable `AUTO-...` SKU is derived from normalized item name and unit.
- Deleting a purchase reverses its stock movement only if enough remaining stock exists. If the purchased stock has already been used, deletion is rejected with HTTP 409.
- Added `/api/inventory` endpoint and route.
- Migration `0010_inventory_suppliers` adds supplier, inventory and stock-movement tables.
- Fixed fresh-database migration ordering so `0001_foundation_tables` runs before the purchase table that references `app_users`.

## Business rules
- Stock in from a purchase increases quantity and recalculates weighted-average cost.
- Manual stock-out cannot reduce stock below zero.
- Supplier and item records are isolated by both user and business unit.
- Payment status is intentionally not inferred. This release does not yet create accounts payable, record supplier payments, post journals, or change profit/loss. Those require payment terms and payment-status fields approved by the owner.

## Routes
- `GET /api/inventory?unit=amishop|amiya`
- `POST /api/inventory` with action `item`, `supplier`, or `adjustment`
- Existing `GET /api/purchases?unit=...` and `POST /api/purchases` now integrate stock and suppliers.

## Validation status
- `node --check` passed for `_db.mjs`, `purchases.mjs`, `inventory.mjs`, and extracted inline scripts from both HTML pages.
- Existing dependency-free test subset and the new v1.1 static integration tests are included. Full test execution could not be completed in this environment because the `pg` dependency was not installed; `npm ci` timed out.
- No live PostgreSQL database migration, production deployment, or real-account transaction test was run. Configure the database and test in a staging environment before production use.
