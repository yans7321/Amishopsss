# AMISHOP Business OS — Data Migration v0.8

Tanggal: 23 November 2026

## Fokus tahap ini

Tahap ini memperluas fondasi PostgreSQL YANS untuk data pekerja, tarif historis, payroll, audit trail, dan pencatatan proses impor. Seluruh perubahan bersifat additive: tidak ada tabel/kolom lama yang dihapus dan tidak ada data workbook lama yang ditimpa oleh migrasi skema.

## Skema baru (migration 0009)

- `yans_worker_rates`: tarif pekerja dengan rentang tanggal berlaku. Tarif pada item payroll disimpan sebagai snapshot sehingga perubahan tarif di masa depan tidak mengubah gaji historis.
- `yans_payroll_periods`: periode gajian dengan status draft/approved/paid/void.
- `yans_payroll_items`: rincian pekerja, kuantitas, tarif, bruto, tambahan, potongan kasbon, potongan lain, dan nilai bersih.
- `app_audit_log`: jejak aksi aplikasi per pengguna, unit bisnis, modul, dan entitas.
- `yans_import_runs`: status dan ringkasan setiap proses impor/migrasi.

## Endpoint pemeriksaan

`GET /api/migration-status` (wajib sesi login) mengembalikan jumlah record per modul, daftar migrasi yang telah diterapkan, serta versi dan nama key workbook. Endpoint tidak mengembalikan nominal gaji, rincian pekerja, atau isi transaksi.

## Aturan akuntansi yang dikunci

- Tarif historis tersalin ke baris payroll, bukan dihitung ulang dari tarif terbaru.
- Potongan kasbon dicatat terpisah dari bruto dan potongan lain.
- Pencatatan kasbon tidak otomatis menjadi biaya payroll; pengurangan saldo harus direkonsiliasi pada transaksi kasbon.
- Periode gajian dapat ditinjau dan disetujui sebelum ditandai dibayar.

## Status dan batasan

- Skema SQL telah ditambahkan dan lolos pemeriksaan sintaks JavaScript serta pengujian kontrak/static.
- Database PostgreSQL sungguhan belum tersedia di lingkungan build ini; migration belum dijalankan pada database produksi.
- Belum ada proses backfill otomatis dari `gajiStatus` ke tabel payroll baru. Workbook legacy tetap dipertahankan sebagai sumber arsip sampai mapping setiap bentuk data gaji diverifikasi dari kode dan sampel data riil.
- Endpoint status adalah pemeriksaan, bukan bukti bahwa data sudah dipindahkan.

## Langkah berikut

1. Jalankan migration 0009 pada database staging.
2. Verifikasi skema dan constraint dengan data uji.
3. Petakan bentuk data `gajiStatus` dan pekerja dari workbook lama.
4. Buat importer idempotent dengan laporan jumlah imported/skipped/needs_review.
5. Hubungkan layar gajian ke endpoint payroll setelah mapping dan validasi disetujui.
