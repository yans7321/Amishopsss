// Konveksi YANS — document enhancements v0.9
// Adds an individual delivery note preview/download without replacing legacy flows.
(function () {
  'use strict';
  if (typeof window === 'undefined') return;

  function getDb() { return (typeof db !== 'undefined') ? db : null; }
  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) {
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]);
    });
  }
  function qty(item) {
    return (item.variants || []).reduce(function (sum, v) { return sum + (Number(v.jumlah) || 0); }, 0);
  }
  function detailRows(item) {
    return (item.variants || []).map(function (v) {
      return '<tr><td>' + esc(v.warna || '-') + '</td><td>' + esc(v.ukuran || v.size || '-') + '</td><td class="num">' + (Number(v.jumlah) || 0) + '</td></tr>';
    }).join('');
  }

  window.previewKirimanNota = function (id) {
    var data = getDb();
    if (!data || !Array.isArray(data.tab5)) return alert('Data kiriman belum tersedia.');
    var item = data.tab5.find(function (x) { return String(x.id) === String(id); });
    if (!item) return alert('Transaksi kiriman tidak ditemukan.');
    var container = document.getElementById('preview-content');
    var modal = document.getElementById('preview-modal');
    if (!container || !modal) return alert('Area preview dokumen tidak ditemukan.');

    var jobId = item.jobId;
    var sameJob = data.tab5.filter(function (x) {
      return jobId != null ? String(x.jobId) === String(jobId) : (x.kode || '') === (item.kode || '');
    });
    var seq = sameJob.findIndex(function (x) { return String(x.id) === String(item.id); }) + 1;
    var totalQty = qty(item);
    var today = new Date().toLocaleDateString('id-ID');
    var pdfTitle = 'Nota_Kiriman_' + String(item.kode || item.id).replace(/[^a-z0-9_-]/gi, '_') + '_' + String(item.id);
    if (typeof currentPdfTitle !== 'undefined') currentPdfTitle = pdfTitle;

    container.innerHTML = '<article class="yans-doc"><style>' +
      '.yans-doc{font-family:Arial,sans-serif;color:#172033;padding:24px;background:#fff;max-width:780px;margin:auto}.yans-doc h2{font-size:23px;margin:0}.yans-doc .muted{color:#64748b;font-size:12px}.yans-doc .rule{border:0;border-top:2px solid #263246;margin:16px 0}.yans-doc .meta{display:grid;grid-template-columns:1fr 1fr;gap:8px 20px;font-size:12px;margin:16px 0}.yans-doc table{width:100%;border-collapse:collapse;font-size:12px;margin-top:14px}.yans-doc th,.yans-doc td{padding:10px;border-bottom:1px solid #e2e8f0;text-align:left}.yans-doc th{background:#f1f5f9}.yans-doc .num{text-align:right}.yans-doc .total{font-size:17px;font-weight:800;text-align:right;margin-top:18px}.yans-doc .sign{display:flex;justify-content:space-between;margin-top:45px;text-align:center;font-size:12px}.yans-doc .sign>div{width:42%}@media print{.yans-doc{padding:0}}</style>' +
      '<div style="display:flex;justify-content:space-between;gap:16px;align-items:flex-start"><div><h2>KONVEKSI YANS</h2><div class="muted">NOTA / BUKTI PENGIRIMAN BARANG</div></div><div style="text-align:right;font-size:12px"><b>NO. KIRIMAN</b><br>' + esc(item.kode || ('KIR-' + item.id)) + '-' + seq + '<br><span class="muted">Dicetak: ' + today + '</span></div></div><hr class="rule">' +
      '<div class="meta"><div><span class="muted">Pelanggan / Perusahaan</span><br><b>' + esc(item.perusahaan || '-') + '</b></div><div><span class="muted">Tanggal Kirim</span><br><b>' + esc(item.tanggal || '-') + '</b></div><div><span class="muted">Model / Barang</span><br><b>' + esc(item.model || '-') + '</b></div><div><span class="muted">Status Pengiriman</span><br><b>' + esc(item.statusKiriman || '-') + '</b></div><div><span class="muted">Penerima</span><br><b>' + esc(item.penerima || '-') + '</b></div><div><span class="muted">Kode Pekerjaan</span><br><b>' + esc(item.kode || '-') + '</b></div></div>' +
      '<table><thead><tr><th>Warna</th><th>Ukuran</th><th class="num">Jumlah</th></tr></thead><tbody>' + detailRows(item) + '</tbody></table>' +
      '<div class="total">Total dikirim: ' + totalQty.toLocaleString('id-ID') + ' pcs</div>' +
      (item.catatan ? '<p class="muted" style="margin-top:16px"><b>Catatan:</b> ' + esc(item.catatan) + '</p>' : '') +
      '<div class="sign"><div>Pengirim,<br><br><br><b>( __________________ )</b></div><div>Penerima,<br><br><br><b>( ' + esc(item.penerima || '__________________') + ' )</b></div></div></article>';
    modal.classList.remove('hidden'); modal.classList.add('flex');
  };

  function addDeliveryButtons() {
    var data = getDb();
    if (!data || !Array.isArray(data.tab5)) return;
    var tbody = document.getElementById('table-tab5');
    if (!tbody) return;
    Array.prototype.forEach.call(tbody.querySelectorAll('tr'), function (tr, index) {
      if (tr.querySelector('.yans-delivery-note')) return;
      var row = data.tab5[index];
      if (!row) return;
      var actionCell = tr.lastElementChild;
      if (!actionCell) return;
      var btn = document.createElement('button');
      btn.type = 'button'; btn.className = 'yans-delivery-note text-emerald-700 bg-emerald-50 border border-emerald-100 hover:bg-emerald-100 px-3 py-1.5 rounded-lg shadow-2xs font-bold transition';
      btn.textContent = 'Nota PDF';
      btn.addEventListener('click', function () { window.previewKirimanNota(row.id); });
      actionCell.appendChild(btn);
    });
  }

  function install() {
    if (typeof window.renderTableTab5 === 'function' && !window.renderTableTab5.__yansDocWrapped) {
      var original = window.renderTableTab5;
      var wrapped = function () { var result = original.apply(this, arguments); addDeliveryButtons(); return result; };
      wrapped.__yansDocWrapped = true;
      window.renderTableTab5 = wrapped;
      addDeliveryButtons();
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', install);
  else install();
  // The legacy application defines renderTableTab5 during initial script evaluation;
  // retry once the app has finished loading without using network or external dependencies.
  window.addEventListener('load', install);
})();
