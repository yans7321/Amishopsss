# AMISHOP Business OS — Migration Package v0.4

## What changed in this package

1. `/` is now the AMISHOP Business OS portal shell.
2. The original Konveksi YANS application is preserved under `/konveksi-yans/` with its original HTML forms, operational navigation, JS modules, CSS, and logo/image assets.
3. The portal's Konveksi YANS navigation and unit selector open the preserved YANS application. The YANS app has a return link to the AMISHOP portal.
4. Shared `/api/*` Netlify Functions remain at the root, so the YANS sub-application continues to call the same backend endpoints.
5. Authentication now issues an `amishop_session` HttpOnly, SameSite=Lax cookie (Secure on HTTPS). The browser app and YANS data modules send same-origin requests and no longer depend on a browser-stored bearer token. The API still returns/accepts the legacy bearer token temporarily for compatibility with existing clients.
6. Legacy local accounts can be upgraded on successful credential match by creating the server account and then signing in through the server.
7. The mobile portal menu now opens the sidebar rather than showing a placeholder alert.

## YANS screens and workflows retained

- Dashboard
- Pekerjaan
- Ambil Jahit
- Storan
- Kiriman Barang
- Kalkulasi Gaji
- Cash Advance / Kasbon
- Laporan Pengeluaran
- Profit & Loss
- Aset Perusahaan
- Arsip & Pekerja
- Member & Akses
- Backup / restore JSON

Original logo and supporting image assets are copied from the supplied YANS source package; no replacement logo was designed.

## Persistence status — important

This is an integration/migration stage, not a production-ready full database cutover.

The existing server APIs cover:
- Pekerjaan and related accessories/documents
- Ambil Jahit
- Storan
- Kiriman Barang
- Pengeluaran
- Kasbon
- Aset
- Pekerja and Perusahaan synchronization

The existing UI still keeps localStorage mirrors for compatibility. Several areas (notably payroll calculations, some archive/member settings, and backup/restore state) have not yet been converted into database-authoritative modules. Some existing sync hooks are best-effort; an API/network failure can leave a local-only change. Do not treat the current portal shell as a verified accounting ledger or use it for production records until the remaining persistence work and browser QA are complete.

## Deployment notes

- Netlify remains the initial test target.
- PostgreSQL must be configured through `DATABASE_URL` (or one of the supported server environment aliases) and the `pg` dependency installed from `package.json`.
- Do not commit database credentials, Google OAuth secrets, or other secrets.
- This package has not been deployed to the user's Netlify account or custom hosting.

## Verification

- JavaScript syntax checks passed for the modified frontend and function modules.
- Existing automated suite: 48/48 passed using the repository's in-memory SQL test driver and a temporary local `pg` import stub. This validates application logic and route integration, not a live PostgreSQL connection.
- Live browser testing, real PostgreSQL migration, mobile visual QA, and deploy verification remain outstanding.

## Next implementation stage

1. Make PostgreSQL authoritative for all YANS modules, including payroll, worker/member/access settings, and archive data.
2. Replace best-effort local-first saves with explicit server success/error states and retry-safe writes.
3. Add a migration/import tool for any meaningful local data that exists on the user's device.
4. Add shared AMISHOP login and role-based access across all business units.
5. Connect YANS financial and production reports to the consolidated group ledger.
