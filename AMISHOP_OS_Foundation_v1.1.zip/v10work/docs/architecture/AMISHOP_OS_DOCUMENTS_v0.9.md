# AMISHOP Business OS — Document Upgrade v0.9

## Scope
This patch continues from Foundation v0.8 and preserves the existing Konveksi YANS workflows.

## Existing YANS document flows retained
- Payroll slip: existing `previewGajianNota(tukang, sd, ed)` and `downloadPdfNota()` remain in `konveksi-yans/index.html`.
- Period expense report: existing `openPreview('tab6')` remains. It reads the selected `report-start-date` and `report-end-date`, existing payroll aggregation, operating expense list, and totals.
- Combined shipment report: existing `openPreview('tab5')` remains unchanged.

## Added
- `konveksi-yans/app-documents.js`
- Adds an individual `Nota PDF` action to each existing Kiriman Barang history row.
- The note reads the selected transaction from `db.tab5` and includes customer/company, shipment date, model, job code, delivery status, recipient, variant/color/size quantities, total pieces, and notes.
- Uses the existing preview modal and existing PDF download function; no new PDF library or remote dependency is introduced.
- User-entered values are HTML-escaped before rendering in the document.

## Important boundaries
- This is a code-level document enhancement. It has not been connected to or tested against the user's live deployment/database.
- Payroll slip and period expense report already existed in the inspected v0.8 source; this patch retains them rather than duplicating their logic.
- AMISHOP and AMIYA purchase notes are not implemented in this YANS-only patch because their purchase transaction schemas/modules are not yet present in the inspected source. They must be added when those modules and their real purchase fields are integrated.
- No logo has been replaced or fabricated. Existing YANS identity assets remain unchanged.
