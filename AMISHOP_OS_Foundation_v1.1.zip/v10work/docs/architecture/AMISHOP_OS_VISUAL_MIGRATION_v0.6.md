# Konveksi YANS UI/UX Upgrade v0.6

## Tujuan
Upgrade UI/UX yang benar-benar terasa tanpa menghapus atau mengganti isi bisnis dan alur kerja Konveksi YANS.

## Perubahan nyata
- Redesain visual sidebar: hierarki grup menu, ukuran, state aktif, kontras, dan spacing.
- Redesain header dan area konten dengan tipografi, ruang, kartu, tabel, dan kontrol input yang konsisten.
- Palet YANS charcoal, warm ivory, dan gold; identitas/logo asli tetap digunakan.
- Command palette pencarian menu melalui tombol pencarian atau Ctrl/Cmd+K.
- Navigasi mobile menjadi drawer dengan backdrop; memilih menu atau menekan Escape menutup drawer.
- Perbaikan keterbacaan tabel, header tabel, form field, dan responsivitas layar kecil.

## Batas perubahan
- Tidak menghapus elemen HTML, ID, handler inline, nama menu, field, tabel, atau fungsi bisnis lama.
- Tidak mengganti algoritma transaksi, validasi, kalkulasi, maupun model data lama.
- CSS dan JS baru adalah lapisan presentasi/navigasi tambahan.

## Status
Ini adalah upgrade UI/UX pada aplikasi statis yang ada. Integrasi PostgreSQL penuh dan uji end-to-end pada hosting produksi tetap merupakan pekerjaan terpisah dan belum dinyatakan selesai.
