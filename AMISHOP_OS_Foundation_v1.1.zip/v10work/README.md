# AMISHOP Business OS — Foundation v0.4

Portal entry: `/`

Preserved Konveksi YANS application: `/konveksi-yans/`

This package integrates the original YANS application as a business-unit route inside the AMISHOP portal and introduces HttpOnly cookie-based sessions while retaining temporary bearer compatibility for older clients.

See `docs/architecture/AMISHOP_OS_MIGRATION_v0.4.md` for feature coverage, persistence limitations, verification scope, and next steps.

## Local development

```bash
npm install
npm test
npm run serve
```

Configure PostgreSQL using `DATABASE_URL` before using server-backed features.
