# AMISHOP Business OS — Foundation v0.5

Paket ini menggabungkan portal AMISHOP dengan aplikasi Konveksi YANS yang dipertahankan sebagai modul.

## Jalankan secara lokal

Gunakan Node.js sesuai `package.json`, lalu jalankan server development yang sudah disediakan proyek. Untuk Netlify Functions, jalankan melalui Netlify CLI dan siapkan environment variables/database sesuai dokumentasi proyek.

## Catatan

- `index.html`: portal AMISHOP Business OS.
- `konveksi-yans/index.html`: aplikasi Konveksi YANS lengkap, dengan jalur asset yang sudah disesuaikan.
- `yans-premium.css`: penyegaran visual presentasi tanpa menghapus konten atau alur kerja.
- `netlify/functions/`: backend Functions yang diwarisi dari proyek sumber.
- `docs/architecture/`: catatan keputusan dan status migrasi.

Paket ini belum boleh dianggap sebagai produksi sebelum database, autentikasi, dan uji regresi end-to-end dinyatakan lulus.
