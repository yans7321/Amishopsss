# AMISHOP Business OS — Foundation v0.7

This package continues the staged migration of the original Konveksi YANS app into AMISHOP Business OS.

## Main addition in v0.7

A session-authenticated, revision-guarded PostgreSQL workbook snapshot endpoint now preserves all operational fields from the legacy YANS `db` object during the gradual conversion of modules to normalized database tables.

See `docs/architecture/AMISHOP_OS_DATA_MIGRATION_v0.7.md` for scope, safeguards, and deployment requirements.

## Local setup

1. Install Node.js 20+.
2. Run `npm ci`.
3. Configure `DATABASE_URL` for PostgreSQL.
4. Run `npm run db:migrate`.
5. Run `npm test`.
6. Deploy to a staging environment before production.

No production database credentials or deployment access are included in this archive.
