// Read-only, authenticated view of YANS migration readiness.
// Counts only; never returns payroll amounts, worker details or workbook rows.
import { isDbConfigured, runMigrations, q, resolveSession } from './_db.mjs';
import { json, errorResponse, safeDbError } from './_http.mjs';

const TABLES = {
  workers: 'yans_pekerja',
  clients: 'yans_perusahaan',
  jobs: 'yans_pekerjaan',
  pickups: 'yans_tailoring_pickups',
  storages: 'yans_storages',
  shipments: 'yans_shipments',
  expenses: 'yans_expenses',
  cashAdvances: 'yans_kasbon',
  assets: 'yans_aset'
};

export default async function handler(req) {
  if (req.method !== 'GET') return errorResponse(405, 'method_not_allowed', 'Gunakan GET.');
  if (!isDbConfigured()) return json({ error: 'db_not_configured', message: 'Database belum dikonfigurasi.' }, 503);
  try {
    await runMigrations();
    const user = await resolveSession(req);
    if (!user) return errorResponse(401, 'unauthorized', 'Sesi tidak valid. Silakan login ulang.');
    const counts = {};
    for (const [key, table] of Object.entries(TABLES)) {
      const rows = await q(`SELECT count(*)::int AS count FROM ${table} WHERE user_id = $1 AND deleted_at IS NULL`, [user.id]);
      counts[key] = Number(rows[0]?.count || 0);
    }
    // These tables do not all have deleted_at; report them separately.
    const payroll = await q(
      `SELECT
         (SELECT count(*)::int FROM yans_payroll_periods WHERE user_id = $1) AS periods,
         (SELECT count(*)::int FROM yans_payroll_items WHERE user_id = $1) AS items,
         (SELECT count(*)::int FROM yans_worker_rates WHERE user_id = $1) AS rates`,
      [user.id]
    );
    counts.payrollPeriods = Number(payroll[0]?.periods || 0);
    counts.payrollItems = Number(payroll[0]?.items || 0);
    counts.workerRates = Number(payroll[0]?.rates || 0);
    const migrationRows = await q('SELECT name, applied_at FROM yans_migrations ORDER BY applied_at, name');
    const workbookRows = await q(
      `SELECT revision, updated_at, payload->'data' AS data
         FROM yans_workbook_state WHERE user_id = $1 AND kind = 'full_backup_v1'`,
      [user.id]
    );
    const workbook = workbookRows.length ? {
      exists: true,
      revision: Number(workbookRows[0].revision),
      updatedAt: workbookRows[0].updated_at,
      keys: Object.keys(workbookRows[0].data || {}).sort()
    } : { exists: false, revision: 0, keys: [] };
    return json({ ok: true, counts, migrations: migrationRows.map((r) => r.name), workbook });
  } catch (error) {
    return safeDbError(error);
  }
}
