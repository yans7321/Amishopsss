import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const db = fs.readFileSync(new URL('../netlify/functions/_db.mjs', import.meta.url), 'utf8');
const status = fs.readFileSync(new URL('../netlify/functions/migration-status.mjs', import.meta.url), 'utf8');
const toml = fs.readFileSync(new URL('../netlify.toml', import.meta.url), 'utf8');

test('phase 9 creates historical worker rates and payroll tables without destructive statements', () => {
  assert.match(db, /0009_payroll_audit_migration/);
  assert.match(db, /CREATE TABLE IF NOT EXISTS yans_worker_rates/);
  assert.match(db, /CREATE TABLE IF NOT EXISTS yans_payroll_periods/);
  assert.match(db, /CREATE TABLE IF NOT EXISTS yans_payroll_items/);
  assert.match(db, /cash_advance_deduction numeric/);
  assert.doesNotMatch(db, /DROP TABLE|TRUNCATE TABLE/);
});

test('phase 9 adds audit and import-run traceability', () => {
  assert.match(db, /CREATE TABLE IF NOT EXISTS app_audit_log/);
  assert.match(db, /CREATE TABLE IF NOT EXISTS yans_import_runs/);
});

test('migration status is read-only, authenticated and exposes counts only', () => {
  assert.match(status, /resolveSession\(req\)/);
  assert.match(status, /count\(\*\)/i);
  assert.match(status, /return json\(\{ ok: true, counts, migrations:/);
  assert.doesNotMatch(status, /INSERT INTO|UPDATE |DELETE FROM/);
});

test('migration status route is registered', () => {
  assert.match(toml, /from = "\/api\/migration-status"[\s\S]*?to = "\/.netlify\/functions\/migration-status"/);
});
