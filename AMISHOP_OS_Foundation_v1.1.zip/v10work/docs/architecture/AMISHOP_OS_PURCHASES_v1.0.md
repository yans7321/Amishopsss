# AMISHOP Business OS — Purchase Documents v1.0

## Scope
Additive purchase-document module for AMISHOP and AMIYA DAILY. It does not alter or remove the existing Konveksi YANS workflow.

## Included
- `/pembelian/` page with unit switch (AMISHOP / AMIYA DAILY).
- Purchase input: date, supplier, invoice number, notes, multiple item rows, SKU, unit, quantity, unit price, additional tax/cost.
- Live subtotal and grand-total calculation.
- Document preview and browser print / Save as PDF.
- Purchase history list from authenticated server endpoint.
- PostgreSQL `purchase_documents` table with user ownership, unit constraint, JSONB item lines, numeric totals and index.
- `GET /api/purchases?unit=amishop|amiya`, `POST /api/purchases`, and `DELETE /api/purchases?id=...`.
- Unit-level separation and per-user authorization via existing session resolver.

## Boundaries / not yet implemented
- This is a first purchase-document ledger, not a complete inventory or accounts-payable system.
- Saving requires a working authenticated session and configured PostgreSQL database. If unavailable, the UI explicitly reports that save failed; preview/print can still be used as a draft.
- Does not automatically change stock, create supplier balances, post journal entries, or update P&L. Those require product/inventory and accounting modules plus approved business rules.
- Brand logos were not fabricated; document header uses the unit's text identity until official logo assets are supplied.
- No production database migration or live deployment was run in this environment.

## Validation
Run `node --check netlify/functions/purchases.mjs` and `node --check netlify/functions/_db.mjs`. Browser UI should be tested locally with an authenticated session and PostgreSQL before production use.
